### R script pour le bloc "Analyse"
### Cours "Introduction à l'analyse de données avec R"
### Date: Juin 2023
### Auteur: The R Bootcamp


### Statistiques simplaes ----------------------------

# Lire le fichier Tourismus.csv et l'assigner à l'objet `data`

# Calculer la moyenne (mean()) des variables Besucher et Daurer

# Calculer la moyenne (mediane()) des variables Besucher et Daurer

# Calculer l'écart type (sd()) des variables Besucher et Daurer

# Calculer la correlation (cor()) des variables Besucher et Daurer

### Graphiques simples ----------------------------

# Tracer un histogramme (hist()) pour la variable Besucher

# Plotte ein Histogram (hist()) für die Variable Dauer

# Tracer un nuage de points (plot()) pour les variables Dauer et Besucher

# Remplacer les axes du diagramme de dispersion par des échelles logarithmiques

# Tracer un diagramme de boîte à moustaches pour les Besucher en fonction de la Region
