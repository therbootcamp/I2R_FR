# load packages
library(tidyverse)

# load data
baselers <- read_csv("1_Data/baselers.csv")

# analyze
summary(baselers)

# regression
lm(weight ~ sex, data = baselers)
